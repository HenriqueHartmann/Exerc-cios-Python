qcd = int(input("digite a quantidade de cigarros fumados p/dia: "))
qaf = int(input("digite a quantos anos já fumou: "))
totalCigarros = (qaf*365)*qcd
diasPerdidos = (totalCigarros*10)/60/24
print("Um fumante que fuma",qcd,"cigarros p/dia e há",qaf,"ano(s) perde",int(diasPerdidos),"dias de sua vida")

