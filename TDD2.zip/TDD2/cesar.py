from string import ascii_lowercase

#Recebe chave e o alfabeto e devolve um dicionário cifrado
def dicionarioCesar(chave, ascii_lowercase):
    dicionario = {}
    i = 0
    for posicao, elemento in enumerate(ascii_lowercase):
        if posicao > (len(ascii_lowercase) - chave):
            dicionario[elemento] = ascii_lowercase[i]
            i+=1   
        else:    
            dicionario[elemento] = ascii_lowercase[posicao+(chave-1)]
    return dicionario
#Recebe uma mensagem e criptografa com um dicionário cifrado
def codificaMensagem(mensagem, chave):
    dicionario = dicionarioCesar(chave, ascii_lowercase)
    mensagem = mensagem.lower()
    lista = []
    for letra in mensagem:
        if letra.isalpha():
            lista.append(dicionario[letra])
    cifra = ''.join(lista)    
    return cifra