p = int(input("digite o preco da mercadoria:"))
d = int(input("digite o por. do desconto da mercadoria:"))
pd = (p/100) * d
np = p - pd
print("valor do desconto",pd," valor do produto",np)