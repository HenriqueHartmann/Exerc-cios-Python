kmp = float(input("digite os km percorridos: "))
qdc = int(input("digite a quantidade de dias pelos quais o carro foi alugado: "))
skmp = kmp * 0.15
sqdc = qdc * 60.00
total = skmp + sqdc
print("R$",total)