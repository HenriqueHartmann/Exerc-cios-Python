salario = int(input("DIGITE O SEU SALARIO:"))
idade = int(input("DIGITE A SUA IDADE:"))

if salario >= 1000 and idade >= 18 :
    print("Voce pode comprar a moto")
else:
    print("voce nao pode comprar a moto")