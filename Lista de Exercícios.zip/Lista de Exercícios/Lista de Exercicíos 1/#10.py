p = 2**1000000
s = str(p)
for i in range(len(s)):
    print(i)
# print("A quantidade de dígitos em 2^1000000 é :",len(s))