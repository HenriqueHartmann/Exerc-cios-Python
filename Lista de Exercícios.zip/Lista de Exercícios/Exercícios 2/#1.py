a = 5
b = 5.0
c = 4.3
d = -2
e = 100
f = 1.333
g = "10"
print("1- ",type(a)," 2- ",type(b)," 3- ",type(c)," 4- ",type(d)," 5- ",type(e)," 6- ",type(f)," 7- ",type(g))