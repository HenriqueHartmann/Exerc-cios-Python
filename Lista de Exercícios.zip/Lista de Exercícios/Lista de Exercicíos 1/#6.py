d = int(input("digite o valor da distancia em km:"))
vm = int(input("digite a velocidade media em km/h:"))
t = d/vm
print(t,"h")