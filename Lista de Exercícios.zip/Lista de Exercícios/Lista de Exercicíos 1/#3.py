d = int(input("digite os dias:"))
h = int(input("digite as horas:"))
m = int(input("digite os minutos:"))
s = int(input("digite os segundos:"))
horas = d*24 + h
minutos = horas*60 + m
segundos = minutos*60 + s
print(segundos)