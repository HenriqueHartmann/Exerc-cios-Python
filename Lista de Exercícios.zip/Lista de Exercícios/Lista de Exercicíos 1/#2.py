a = int(input("DIGITE O VALOR EM METROS: "))
print(a / 1000,"mm")