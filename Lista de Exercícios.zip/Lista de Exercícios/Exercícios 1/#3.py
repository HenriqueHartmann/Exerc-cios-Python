a = 2
b = 3
c = 14
print(a+b+c)
