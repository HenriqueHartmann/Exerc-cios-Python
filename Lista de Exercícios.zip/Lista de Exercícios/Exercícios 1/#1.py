a = 6500
print((a/100)*5 + a)
