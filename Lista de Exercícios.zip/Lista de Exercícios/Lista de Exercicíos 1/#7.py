d = int(input("DIGITE 1 PARA C. PARA F E 2 PARA F. PARA C.: "))
if d == 1:
    c = int(input("DIGITE A TEMPERATURA A SER CONVERTIDA(C. para F.): "))
    f = (c * (9/5)) + 32
    print(f,"°F")
elif d == 2:
    f = int(input("DIGITE A TEMPERATURA A SER CONVERTIDA(F. para C.): "))
    c = (f - 32) * (5/9)
    print(c,"°C")
