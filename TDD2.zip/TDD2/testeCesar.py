import unittest
from cesar import codificaMensagem

class TestCifrador(unittest.TestCase):
    def test_cifra_1_letra(self):
        self.assertEqual(codificaMensagem('a', 3), 'c')
        self.assertEqual(codificaMensagem('b', 3), 'd')
        self.assertEqual(codificaMensagem('y', 3), 'a')
        self.assertEqual(codificaMensagem('z', 3), 'b')

    def test_cifra_1_letra_maiuscula(self):
        self.assertEqual(codificaMensagem('A', 3), 'c')
        self.assertEqual(codificaMensagem('B', 3), 'd')
        self.assertEqual(codificaMensagem('Y', 3), 'a')
        self.assertEqual(codificaMensagem('Z', 3), 'b')

    def test_cifra_2_letras(self):
        self.assertEqual(codificaMensagem('ab', 3), 'cd')
        self.assertEqual(codificaMensagem('yz', 3), 'ab')

    def test_cifra_frase(self):
        self.assertEqual(codificaMensagem('Python', 3), 'ravjqp')
        self.assertEqual(codificaMensagem('Testes', 3), 'vguvgu')

    def test_cifra_com_espacos(self):
        self.assertEqual(codificaMensagem('Python Testes', 3), 'ravjqpvguvgu')              
    
    def test_cifra_com_chave_4(self):
        self.assertEqual(codificaMensagem('abc', 4), 'def')

if __name__ == "__main__":
    unittest.main()