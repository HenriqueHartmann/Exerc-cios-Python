s = int(input("digite o seu salario:"))
pa = int(input("digite a porcentagem do aumento:"))
aum = (s/100) * pa
ns = s + aum
print("valor do aumento: ",aum," valor do novo salario: ",ns)