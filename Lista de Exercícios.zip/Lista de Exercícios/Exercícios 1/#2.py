a = input("Digite seu nome: ")
print("Meu nome e: "+ a)
