exec = 5.8
provas = 7
media = ((exec + provas) / 2)
# if media >= 6 :
#     print("passou")
# else:
#     print("nao passou")
status = media >= 7
print(status)