a = int(input("DIGITE O PRIMEIRO NUMERO: "))
b = int(input("DIGITE O SEGUNDO NUMERO: "))
print(a+b)
