x = 5
x = 5.0
x = 4.3
x = -2
x = 100
x = 1.333
x = "10"
print(type(x))