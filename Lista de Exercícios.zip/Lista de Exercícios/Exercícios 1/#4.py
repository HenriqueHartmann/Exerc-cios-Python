a = ' Meu  nome '
b = ' e '
c = ' Henrique '
print(a+b+c)